package com.mycompany.treemainclass;

import java.util.Scanner;

public class TreeMainClass {
    public static void main(String[] args) {
        int islem;
        int value;
        Node max;
        Node min;
        Scanner scan = new Scanner(System.in);
        Tree tree = new Tree();
        do{
            System.out.println("1.Ekle\n2.Çıkar\n3.Maximum değeri bul\n4.Minimum değeri bul\n5.Pre-order listele\n-1.Çıkış");
            System.out.println("Yapmak istediğiniz işlemi giriniz:");
            islem = scan.nextInt();
            switch(islem){
                case 1:
                    System.out.println("Eklenecek sayıyı giriniz:");
                    value = scan.nextInt();
                    if(tree.getRoot() == null){
                        tree.setRoot(new Node(value));
                        tree.getRoot().setPlace(0);
                        break;
                    }
                    tree.Add(value,tree.getRoot());
                    break;
                case 2:
                    System.out.println("Çıkarılacak sayıyı giriniz:");
                    value = scan.nextInt();
                    tree.Delete(value);
                    break;
                case 3:
                    max = tree.FindMax(tree.getRoot());
                    System.out.println("Maksimum değer:"+max.getValue());
                    break;
                case 4:
                    min = tree.FindMin(tree.getRoot());
                    System.out.println("Minimum değer:"+min.getValue());
                    break;
                case 5:
                    tree.PreList(tree.getRoot());
                    System.out.println("\n");
                    break;
            }
        }
        while(islem!=-1);
    }
}
