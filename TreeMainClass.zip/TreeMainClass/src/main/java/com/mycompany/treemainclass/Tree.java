package com.mycompany.treemainclass;

import java.util.Scanner;

public class Tree {

    private Node root = null;
    Scanner scan = new Scanner(System.in);

    public void Add(int value, Node temp) {
        if (temp.getValue() > value) {
            if (temp.getLeft() == null) {
                Node newNode = new Node(value, temp);
                newNode.setPlace(1);
                temp.setLeft(newNode);
                return;
            }
            Add(value, temp.getLeft());
            return;
        }
        if (temp.getRight() == null) {
            Node newNode = new Node(value, temp);
            newNode.setPlace(2);
            temp.setRight(newNode);
            return;
        }
        Add(value, temp.getRight());
    }

    public void Delete(int value) {
        Node temp = Find(value, root);
        if (temp.equals(root)) {
            root = null;
            return;
        }
        if (temp.getPlace() == 1) {
            temp.getParent().setLeft(null);
            return;
        }
        if (temp.getPlace() == 2) {
            temp.getParent().setRight(null);
            return;
        }
    }

    public Node FindMax(Node temp) {
        if (root == null) {
            return null;
        }
        while (temp.getRight() != null) {
            temp = temp.getRight();
        }
        return temp;
    }

    public Node FindMin(Node temp) {
        if (root == null) {
            return null;
        }
        while (temp.getLeft() != null) {
            temp = temp.getLeft();
        }
        return temp;
    }

    public void PreList(Node temp) {
        if (temp == null) {
            return;
        }
        System.out.print(temp.getValue() + " ");
        PreList(temp.getLeft());
        PreList(temp.getRight());

    }

    public void InList(Node temp) {
        if (temp == null) {
            return;
        }

        PreList(temp.getLeft());
        System.out.print(temp.getValue() + " ");
        PreList(temp.getRight());

    }

    public void PostList(Node temp) {
        if (temp == null) {
            return;
        }

        PreList(temp.getLeft());
        PreList(temp.getRight());
        System.out.print(temp.getValue() + " ");

    }

    private Node Find(int value, Node temp) {
        if (temp != null) {
            while (temp.getValue() != value) {
                if (temp.getLeft() != null) {
                    temp = temp.getLeft();
                } else if (temp.getRight() != null) {
                    temp = temp.getRight();
                } else {
                    temp = temp.getParent().getRight();
                }
            }
            return temp;
        }
        return null;
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node root) {
        this.root = root;
    }
    
}
