package com.mycompany.treemainclass;

public class Node {
    private int value;
    private int place;
    private Node left;
    private Node right;
    private Node Parent;
    public Node() {
        
    }

    public Node(int value) {
        this.value = value;
        this.left = null;
        this.right = null;
        this.Parent = null;
    }

    public Node(int value, Node Parent) {
        this.value = value;
        this.Parent = Parent;
        this.left = null;
        this.right = null;
    }

    public int getValue() {
        return value;
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public void setRight(Node right) {
        this.right = right;
    }

    public Node getParent() {
        return Parent;
    }

    public void setParent(Node Parent) {
        this.Parent = Parent;
    }

    public int getPlace() {
        return place;
    }

    public void setPlace(int place) {
        this.place = place;
    }
    
    
}
