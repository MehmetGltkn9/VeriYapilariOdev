package com.mycompany.treemain;

import java.util.ArrayList;
import java.util.Scanner;

public class Tree {
    private ArrayList <Node> treeList = new ArrayList<>();
    private Node root = null;
    Scanner scan = new Scanner(System.in);
    public void AddRoot(){
        if(root!=null){
            System.out.println("Zaten kök var!!");
            return;
        }
        System.out.println("Kökün değerini giriniz:");
        int value = scan.nextInt();
        root = new Node(value,null);
        root.yer=0;
        treeList.add(root);
    }
    
    public void AddLeft(int value,int ParentValue){
        Node parent = Find(ParentValue,root);
        if(parent.getLeft()!=null){
            System.out.println("Eklemek istenilen yer zaten dolu!!!");
            return;
        }      
        Node newNode = new Node(value,parent);
        parent.setLeft(newNode);
        newNode.yer = 1;
        System.out.println("eklendi");
        treeList.add(newNode);
    }
    
    public void AddRight(int value,int ParentValue){
        Node parent = Find(ParentValue,root);
        if(parent.getRight()!=null){
            System.out.println("Eklemek istenilen yer zaten dolu!!!");
            return;
        }
        Node newNode = new Node(value,parent);
        parent.setRight(newNode);
        newNode.yer = 2;
        treeList.add(newNode);
    }
    
    public void Delete(int value){
        Node temp = Find(value,root);
        if(temp.yer == 0){
            root = null;
            return;
        }
        if(temp.yer == 1){
            temp.getParent().setLeft(null);
            return;
        }
        if(temp.yer == 2){
            temp.getParent().setRight(null);
        }
    }
    
    public void Print(Node root){
        if (root != null) {
            Print(root.getLeft());
            System.out.print(root.getValue()+" ");
            Print(root.getRight());
	}
    }
    
    private Node Find(int value,Node temp){
        if (temp != null) {
            while(temp.getValue()!=value){
                if(temp.getLeft()!=null){
                    temp = temp.getLeft();
                }          
                else if(temp.getRight()!=null){
                    temp = temp.getRight();
                }
                else
                    temp = temp.getParent().getRight();
            }
            return temp;
	}
        return null;
    }

    public Node getRoot() {
        if(root!=null){
            return root;
        }
        Node root = new Node();
        return root;
    }
    
}