package com.mycompany.treemain;

import java.util.Scanner;

public class TreeMain {
    public static void main(String[] args) {
        int islem ;
        int parentValue;
        int value;
        Scanner scan = new Scanner(System.in);
        Tree tree = new Tree();
        do{
            System.out.println("1.Kök ekle\n2.Sola ekle\n3.Sağa ekle\n4.Sil\n5.Listele\n-1.Çıkış");
            System.out.println("Yapmak istediğiniz işlemi giriniz:");
            islem = scan.nextInt();
            switch(islem){
                case 1:
                    tree.AddRoot();                  
                    break;
                case 2:
                    System.out.println("Hangi sayının soluna eklemek istiyorsunuz?");
                    parentValue = scan.nextInt();
                    System.out.println("Eklenecek sayıyı giriniz:");
                    value = scan.nextInt();
                    tree.AddLeft(value,parentValue);
                    break;
                case 3:
                    System.out.println("Hangi sayının sağına eklemek istiyorsunuz?");
                    parentValue = scan.nextInt();
                    System.out.println("Eklenecek sayıyı giriniz:");
                    value = scan.nextInt();
                    tree.AddRight(value,parentValue);
                    break;
                case 4:
                    System.out.println("Silinecek sayıyı giriniz:");
                    value = scan.nextInt();
                    tree.Delete(value);
                    break;
                case 5:
                    tree.Print(tree.getRoot());
                    break;
            }
        }
        while(islem!=-1);
    }
}
